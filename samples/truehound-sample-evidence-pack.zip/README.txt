Truehound sample evidence pack

This is the evidence pack the live demo files when its quarterly access review is signed.
Acme, its people and its apps are made up. Removals in the demo are simulated, and so are their re-reads.

Check it yourself: the SHA-256 of every file except this one and manifest.json is listed in manifest.json.
  shasum -a 256 decisions.csv
and compare the result with the entry for decisions.csv in manifest.json.

Truehound records the population, decisions and removals. It does not certify compliance; your auditor decides.
